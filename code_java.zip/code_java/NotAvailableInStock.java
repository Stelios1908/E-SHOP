


@SuppressWarnings("serial")
public class NotAvailableInStock extends Exception {
		NotAvailableInStock(){
			super("The item is not available in Stock.Sorry for the incoveniance");
		}
		
}
