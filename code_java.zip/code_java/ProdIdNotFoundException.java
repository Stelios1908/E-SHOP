
public class ProdIdNotFoundException extends Exception{
	public ProdIdNotFoundException() {
	super("\n======================================================\nProdIdNotFoundException\n======================================================"+
	"\nReturning to product category...");
	}
}